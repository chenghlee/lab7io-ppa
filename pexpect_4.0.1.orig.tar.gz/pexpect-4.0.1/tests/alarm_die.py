import signal, time

signal.alarm(1) # Schedule SIGALRM in 1s

time.sleep(6)